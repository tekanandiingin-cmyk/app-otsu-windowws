# OTSU SHOP — Aplikasi Windows (khusus pembeli)

Membuka halaman toko pembeli. Tidak ada file/kode admin, database, atau token di dalam proyek ini.
Alamat toko ada di baris `TOKO_URL` pada `main.js`.

Build: jalankan workflow **Build EXE (Windows)** di GitHub Actions, hasilnya `OtsuShop-Pembeli.exe` (portable, tanpa install).
Lokal (Windows): `npm install` lalu `npm run dist` -> hasil di folder `dist/`.
