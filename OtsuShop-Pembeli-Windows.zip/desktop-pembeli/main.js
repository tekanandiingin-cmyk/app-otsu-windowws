// OTSU SHOP PREMIUM - aplikasi PEMBELI (Windows)
// Hanya membuka halaman toko publik. Tidak ada file/kode admin di dalam aplikasi ini,
// dan semua alamat yang mengandung "admin" diblokir di sisi aplikasi.
const { app, BrowserWindow, Menu, shell, session, net } = require('electron');
const path = require('path');

const TOKO_URL = 'https://produk.otsushop.my.id/';   // <-- ganti jika domain berubah
const TOKO_HOST = new URL(TOKO_URL).host;
const MIN_SPLASH_MS = 800;

const SPLASH_HTML = `<!doctype html><html><head><meta charset="utf-8"><style>
:root{--bg:#F1F4FA;--ink:#0E1330;--mute:#586282}
@media (prefers-color-scheme:dark){:root{--bg:#0B1020;--ink:#EEF1FF;--mute:#9AA4C9}}
html,body{margin:0;height:100%;background:var(--bg);font-family:"Segoe UI",system-ui,sans-serif;overflow:hidden}
body{display:flex;flex-direction:column;align-items:center;justify-content:center;user-select:none}
h1{margin:20px 0 0;font-size:26px;color:var(--ink);letter-spacing:-.01em}
p{margin:2px 0 0;font-size:13px;font-weight:700;letter-spacing:.3em;color:var(--mute)}
</style></head><body>
<svg viewBox="0 0 108 108" width="112" height="112"><rect width="108" height="108" rx="26" fill="#1F6BFF"/>
<path d="M34,42 L74,42 L77,76 Q77,80 73,80 L35,80 Q31,80 31,76 Z" fill="#fff"/>
<path d="M42,48 L42,38 Q42,28 54,28 Q66,28 66,38 L66,48" fill="none" stroke="#FFE45C" stroke-width="4.5" stroke-linecap="round"/></svg>
<h1>OTSU SHOP</h1><p>PREMIUM</p></body></html>`;

const OFFLINE_HTML = `<!doctype html><html><head><meta charset="utf-8"><style>
:root{--bg:#F1F4FA;--ink:#0E1330;--mute:#586282;--pri:#1F6BFF}
@media (prefers-color-scheme:dark){:root{--bg:#0B1020;--ink:#EEF1FF;--mute:#9AA4C9;--pri:#4D8DFF}}
html,body{margin:0;height:100%;background:var(--bg);font-family:"Segoe UI",system-ui,sans-serif}
body{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center}
h1{margin:0;font-size:22px;color:var(--ink)}p{margin:8px 0 20px;color:var(--mute)}
a{display:inline-block;padding:11px 22px;border-radius:99px;background:var(--pri);color:#fff;font-weight:700;text-decoration:none}
</style></head><body><h1>Tidak ada koneksi</h1><p>Periksa internet kamu. Aplikasi akan mencoba lagi otomatis.</p>
<a href="${TOKO_URL}">Coba lagi</a></body></html>`;

const dataUrl = (html) => 'data:text/html;charset=utf-8,' + encodeURIComponent(html);

function isStore(u) {
  try { const x = new URL(u); return x.protocol === 'https:' && x.host === TOKO_HOST; } catch { return false; }
}
function isAdminUrl(u) {
  try { const x = new URL(u); return x.host === TOKO_HOST && x.pathname.toLowerCase().includes('admin'); } catch { return false; }
}
function openExternalSafe(u) {
  try {
    const p = new URL(u).protocol;
    if (['https:', 'http:', 'mailto:', 'tel:'].includes(p)) shell.openExternal(u);
  } catch { /* abaikan */ }
}

let win = null, splash = null, offline = false, revealed = false;
const t0 = Date.now();

function reveal() {
  if (revealed) return;
  revealed = true;
  const wait = Math.max(0, MIN_SPLASH_MS - (Date.now() - t0));
  setTimeout(() => {
    if (win && !win.isDestroyed()) { win.show(); win.focus(); }
    if (splash && !splash.isDestroyed()) splash.close();
  }, wait);
}

function showOffline() {
  offline = true;
  if (win && !win.isDestroyed()) win.loadURL(dataUrl(OFFLINE_HTML));
  reveal();
}

function createWindows() {
  splash = new BrowserWindow({
    width: 420, height: 320, frame: false, resizable: false, center: true,
    alwaysOnTop: true, skipTaskbar: true, backgroundColor: '#F1F4FA',
    webPreferences: { sandbox: true, contextIsolation: true }
  });
  splash.loadURL(dataUrl(SPLASH_HTML));

  win = new BrowserWindow({
    width: 1180, height: 820, minWidth: 420, minHeight: 600,
    show: false, title: 'OTSU SHOP', backgroundColor: '#F1F4FA',
    autoHideMenuBar: true, icon: path.join(__dirname, 'icon.png'),
    webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false, spellcheck: false }
  });
  win.webContents.setUserAgent(win.webContents.getUserAgent() + ' OtsuShopDesktop/1.0');

  const wc = win.webContents;

  wc.on('did-finish-load', () => {
    if (isStore(wc.getURL())) offline = false;
    reveal();
  });
  wc.on('did-fail-load', (e, code, desc, url, isMain) => {
    if (!isMain || code === -3 || String(url).startsWith('data:')) return;
    showOffline();
  });

  // Pembeli tidak boleh keluar dari toko atau masuk ke halaman admin lewat aplikasi ini.
  wc.on('will-navigate', (e, url) => {
    if (isStore(url) && !isAdminUrl(url)) return;
    e.preventDefault();
    if (!isAdminUrl(url)) openExternalSafe(url);
  });
  wc.setWindowOpenHandler(({ url }) => {
    if (isAdminUrl(url)) return { action: 'deny' };
    if (isStore(url)) wc.loadURL(url); else openExternalSafe(url);
    return { action: 'deny' };
  });

  // Reload: F5 / Ctrl+R
  wc.on('before-input-event', (e, input) => {
    if (input.type !== 'keyDown') return;
    if (input.key === 'F5' || (input.control && input.key.toLowerCase() === 'r')) {
      e.preventDefault();
      if (offline) wc.loadURL(TOKO_URL); else wc.reload();
    }
  });

  // Klik kanan: salin / tempel di kolom isian
  wc.on('context-menu', (e, params) => {
    const items = [];
    if (params.isEditable) items.push({ role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { type: 'separator' }, { role: 'selectAll' });
    else if (params.selectionText) items.push({ role: 'copy' });
    if (items.length) Menu.buildFromTemplate(items).popup({ window: win });
  });

  win.on('closed', () => { win = null; });
  wc.loadURL(TOKO_URL);

  setTimeout(reveal, 12000);   // pengaman: splash tidak menggantung
  setInterval(() => {          // coba lagi otomatis saat offline
    if (offline && win && !win.isDestroyed() && net.isOnline()) win.loadURL(TOKO_URL);
  }, 8000);
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (win) { if (win.isMinimized()) win.restore(); win.focus(); }
  });

  app.on('web-contents-created', (e, contents) => {
    contents.on('will-attach-webview', (ev) => ev.preventDefault());
  });

  app.whenReady().then(() => {
    app.setAppUserModelId('com.otsushop.pembeli.desktop');
    Menu.setApplicationMenu(null);

    const ses = session.defaultSession;
    ses.setPermissionRequestHandler((wc, permission, cb) => cb(permission === 'clipboard-sanitized-write'));
    ses.setPermissionCheckHandler((wc, permission) => permission === 'clipboard-sanitized-write');
    ses.webRequest.onBeforeRequest({ urls: ['https://' + TOKO_HOST + '/*'] }, (details, cb) => {
      const t = details.resourceType;
      cb({ cancel: (t === 'mainFrame' || t === 'subFrame') && isAdminUrl(details.url) });
    });
    // Unduhan (mis. CSV mutasi member): Windows menampilkan dialog "Simpan sebagai"
    ses.on('will-download', (e, item) => {
      item.once('done', (ev, state) => {
        if (state === 'completed') shell.showItemInFolder(item.getSavePath());
      });
    });

    createWindows();
  });

  app.on('window-all-closed', () => app.quit());
}
